angular.module('demo.printer.ctrl', [])

  .controller('PrinterCtrl', function ($scope, $log, $cordovaPreferences) {

  });
